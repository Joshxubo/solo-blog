title: SpringBoot读取配置文件
date: '2019-10-09 18:18:56'
updated: '2019-10-09 18:24:24'
tags: [Note]
permalink: /articles/2019/10/09/1570616336563.html
---
![WeChatd6bd35ce0d517adc37084150f27fbb1e.png](https://img.hacpai.com/file/2019/10/WeChatd6bd35ce0d517adc37084150f27fbb1e-b5ea45c2.png)

SpringBoot读取配置文件

1.IO流读取机密文件(打jar可读取）

```java
InputStream inputStream = AuthorizationHelper.class.getClassLoader()
    .getResourceAsStream("META-INF/default-public.pem");

StringBuilder builder = new StringBuilder();
Assert.notNull(inputStream,()->"inputStream is null");
BufferedInputStream bis = new BufferedInputStream(inputStream,1024);
byte[] buffer = new byte[1024];
int length = 0;
while ((length = bis.read(buffer))!=-1){
  builder.append(new String(buffer,0,length, StandardCharsets.UTF_8));
}
String publicKeyStr = builder.toString();
```

2.@EnableConfigurationProperties 读取配置文件

```java
@Configuration
@EnableConfigurationProperties({RemoteServerProperties.class})
public class RemoteConfiguration {
  //properties配置文件前缀
  @ConfigurationProperties(prefix = "remote.url") 
  @Data
  public static class RemoteServerProperties{
    //aorpApiServer 对应properties文件的aorp-api-server
    private String aorpApiServer;
  }
}

//properties配置文件
remote.url.aorp-api-server: http://192.168.1.159:7777/aorp
```

3.@Value读取配置文件(维护成本高)
